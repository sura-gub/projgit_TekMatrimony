<style>
  section{
    background-color: #cfe2ff;
   padding: 20px;
   margin-top: 185px;
  }
  img:hover{
  }
  </style>
<section>
<center>
<img src="img/msg.png" width="20px" style="margin-right:20px; margin-bottom: 10px;">
<img src="img/insta.png" width="20px" style="margin-right:20px; margin-bottom: 10px;">
<img src="img/fb1.png" width="20px" style="margin-right:20px; margin-bottom: 10px;">
<img src="img/goo.png" width="20px" style="margin-right:20px; margin-bottom: 10px;">
<img src="img/link.png" width="20px" style="margin-right:20px; margin-bottom: 10px;">
<img src="img/git.png" width="20px" style="margin-right:20px; margin-bottom: 10px;">
<img src="img/twit.png" width="20px" style="margin-right:20px; margin-bottom: 10px;">
<div style="font-family: calibri;font-size: 13px;line-height: 20px;letter-spacing: .94px;color: #999;  color: black;" class="mob-pt20 display-2 fs-6"> This website is strictly for matrimonial purpose only and not a dating website. <br>
Copyright © 2023. Desighned By MindTek<br> All rights reserved.<br>
</div></center></section>