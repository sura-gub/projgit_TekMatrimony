<?php
$connect = new PDO('mysql:host=localhost;dbname=id21282115_bluestar','root','');
?>