<?php
$connect=new PDO('mysql:host=localhost;dbname=matrimony','matrimony','K4Qb1SAxhR~4');
?>