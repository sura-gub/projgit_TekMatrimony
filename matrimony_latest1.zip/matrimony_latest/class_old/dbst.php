<?php
$connect=new PDO('mysql:host=localhost;dbname=matrimonytrin','matrimonytraining','b(P{HxrOQ#i$');
?>