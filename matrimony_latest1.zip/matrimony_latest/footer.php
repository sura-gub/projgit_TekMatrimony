<section>
<center>
<div style="font-family: calibri;font-size: 13px;line-height: 20px;letter-spacing: .94px;color: #999;margin: 20px 10px 20px 10px;" class="mob-pt20 display-2 fs-6"> This website is strictly for matrimonial purpose only and not a dating website. <br>
Copyright © 2023. Desighned By MindTek<br> All rights reserved.</div></center>
  </section>